# Page snapshot

```yaml
- generic [active] [ref=e1]:
  - heading "Asmrandle" [level=1] [ref=e2]
  - generic [ref=e14]:
    - img [ref=e16] [cursor=pointer]
    - img [ref=e18] [cursor=pointer]
  - generic [ref=e19]:
    - heading "How to Play" [level=3] [ref=e20]
    - paragraph [ref=e21]:
      - text: Click on the card you believe appears in a higher percentage of decks on
      - link "EDHRec" [ref=e22] [cursor=pointer]:
        - /url: https://edhrec.com
      - text: . This percentage represents how often a card is included in decks where it's eligible to be played — calculated by dividing the number of decks that include the card by the total number of decks it could appear in.
  - generic [ref=e23]:
    - link "LinkedIn" [ref=e24] [cursor=pointer]:
      - /url: https://www.linkedin.com/in/julienplegault/
      - img "LinkedIn" [ref=e25]
    - paragraph [ref=e26]: "Portions of Asmrandle are unofficial Fan Content permitted under the Wizards of the Coast Fan Content Policy. The literal and graphical information presented on this site about Magic: The Gathering, including card images and mana symbols, is copyright Wizards of the Coast, LLC. Asmrandle is not produced by or endorsed by Wizards of the Coast."
```