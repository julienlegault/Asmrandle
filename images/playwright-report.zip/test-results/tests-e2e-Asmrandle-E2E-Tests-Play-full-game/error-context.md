# Page snapshot

```yaml
- generic [active] [ref=e1]:
  - heading "Asmrandle" [level=1] [ref=e2]
  - generic [ref=e14]:
    - generic [ref=e15] [cursor=pointer]:
      - img [ref=e16]
      - generic [ref=e17]: 0.021%
    - generic [ref=e18] [cursor=pointer]:
      - img [ref=e19]
      - generic [ref=e20]: 0.383%
  - generic [ref=e21]:
    - heading "How to Play" [level=3] [ref=e22]
    - paragraph [ref=e23]:
      - text: Click on the card you believe appears in a higher percentage of decks on
      - link "EDHRec" [ref=e24] [cursor=pointer]:
        - /url: https://edhrec.com
      - text: . This percentage represents how often a card is included in decks where it's eligible to be played — calculated by dividing the number of decks that include the card by the total number of decks it could appear in.
  - generic [ref=e25]:
    - link "LinkedIn" [ref=e26] [cursor=pointer]:
      - /url: https://www.linkedin.com/in/julienplegault/
      - img "LinkedIn" [ref=e27]
    - paragraph [ref=e28]: "Portions of Asmrandle are unofficial Fan Content permitted under the Wizards of the Coast Fan Content Policy. The literal and graphical information presented on this site about Magic: The Gathering, including card images and mana symbols, is copyright Wizards of the Coast, LLC. Asmrandle is not produced by or endorsed by Wizards of the Coast."
```